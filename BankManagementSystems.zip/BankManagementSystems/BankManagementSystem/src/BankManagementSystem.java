import java.util.ArrayList;
import java.util.Scanner;

/** Console-based Bank Management System. */
public class BankManagementSystem {
    private static final Scanner sc = new Scanner(System.in);
    private static final Bank bank = new Bank();
    private static int nextAccountNumber = 1001;

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("        BANK MANAGEMENT SYSTEM");
        System.out.println("========================================");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> createAccount();
                case 2 -> depositMoney();
                case 3 -> withdrawMoney();
                case 4 -> transferMoney();
                case 5 -> checkBalance();
                case 6 -> viewAccount();
                case 7 -> searchAccount();
                case 8 -> updateCustomer();
                case 9 -> showTransactions();
                case 10 -> displayAllAccounts();
                case 11 -> closeAccount();
                case 12 -> {
                    running = false;
                    System.out.println("Thank you for using Bank Management System!");
                }
                default -> System.out.println("Invalid choice. Please select 1-12.");
            }
            System.out.println();
        }
        sc.close();
    }

    private static void printMenu() {
        System.out.println("\n--------------- MAIN MENU ---------------");
        System.out.println("1. Create Account");
        System.out.println("2. Deposit Money");
        System.out.println("3. Withdraw Money");
        System.out.println("4. Transfer Money");
        System.out.println("5. Check Balance");
        System.out.println("6. View Account Details");
        System.out.println("7. Search Account by Name");
        System.out.println("8. Update Customer Details");
        System.out.println("9. Transaction History");
        System.out.println("10. Display All Accounts");
        System.out.println("11. Close Account");
        System.out.println("12. Exit");
        System.out.println("------------------------------------------");
    }

    private static void createAccount() {
        System.out.println("\n--- CREATE ACCOUNT ---");
        String name = readNonEmpty("Enter Customer Name: ");
        String phone = readPhone("Enter Phone Number: ");
        String type = readAccountType();
        double initial = readDouble("Enter Initial Deposit: ");

        if (initial < 500) {
            System.out.println("Minimum initial deposit is Rs. 500.");
            return;
        }

        int accountNumber = nextAccountNumber++;
        bank.addAccount(new Account(accountNumber, name, phone, type, initial));
        System.out.println("\nAccount created successfully!");
        System.out.println("Your Account Number is: " + accountNumber);
    }

    private static String readAccountType() {
        while (true) {
            String type = readNonEmpty("Enter Account Type (Savings/Current): ");
            if (type.equalsIgnoreCase("Savings")) return "Savings";
            if (type.equalsIgnoreCase("Current")) return "Current";
            System.out.println("Please enter Savings or Current.");
        }
    }

    private static void depositMoney() {
        Account account = getAccount();
        if (account == null) return;
        double amount = readDouble("Enter Deposit Amount: ");
        if (account.deposit(amount)) {
            System.out.printf("Deposit successful! New Balance: Rs. %.2f%n", account.getBalance());
        } else {
            System.out.println("Amount must be greater than zero.");
        }
    }

    private static void withdrawMoney() {
        Account account = getAccount();
        if (account == null) return;
        double amount = readDouble("Enter Withdrawal Amount: ");
        if (account.withdraw(amount)) {
            System.out.printf("Withdrawal successful! Remaining Balance: Rs. %.2f%n", account.getBalance());
        } else {
            System.out.println("Withdrawal failed. Check the amount and available balance.");
        }
    }

    private static void transferMoney() {
        System.out.println("\n--- MONEY TRANSFER ---");
        int from = readInt("Sender Account Number: ");
        int to = readInt("Receiver Account Number: ");
        double amount = readDouble("Transfer Amount: ");

        if (bank.transfer(from, to, amount)) {
            System.out.println("Transfer successful!");
        } else {
            System.out.println("Transfer failed. Check account numbers and balance.");
        }
    }

    private static void checkBalance() {
        Account account = getAccount();
        if (account != null) {
            System.out.printf("Account: %d | Balance: Rs. %.2f%n",
                    account.getAccountNumber(), account.getBalance());
        }
    }

    private static void viewAccount() {
        Account account = getAccount();
        if (account != null) account.displayDetails();
    }

    private static void searchAccount() {
        String name = readNonEmpty("Enter customer name to search: ");
        ArrayList<Account> results = bank.searchByName(name);
        if (results.isEmpty()) {
            System.out.println("No matching account found.");
            return;
        }
        System.out.println("\nSearch Results:");
        for (Account account : results) account.displayRow();
    }

    private static void updateCustomer() {
        Account account = getAccount();
        if (account == null) return;
        String name = readNonEmpty("Enter new customer name: ");
        String phone = readPhone("Enter new phone number: ");
        account.setCustomerName(name);
        account.setPhoneNumber(phone);
        System.out.println("Customer details updated successfully!");
    }

    private static void showTransactions() {
        Account account = getAccount();
        if (account != null) account.displayTransactions();
    }

    private static void displayAllAccounts() {
        bank.displayAllAccounts();
        System.out.println("Total Accounts: " + bank.getAccountCount());
    }

    private static void closeAccount() {
        Account account = getAccount();
        if (account == null) return;
        if (account.getBalance() != 0) {
            System.out.println("Account cannot be closed while balance is not zero.");
            return;
        }
        if (bank.closeAccount(account.getAccountNumber())) {
            System.out.println("Account closed successfully.");
        }
    }

    private static Account getAccount() {
        int accountNumber = readInt("Enter Account Number: ");
        Account account = bank.findAccount(accountNumber);
        if (account == null) System.out.println("Account not found!");
        return account;
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                double value = Double.parseDouble(sc.nextLine().trim());
                if (Double.isNaN(value) || Double.isInfinite(value)) throw new NumberFormatException();
                return value;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid amount.");
            }
        }
    }

    private static String readNonEmpty(String message) {
        while (true) {
            System.out.print(message);
            String value = sc.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private static String readPhone(String message) {
        while (true) {
            String phone = readNonEmpty(message);
            if (phone.matches("\\d{10}")) return phone;
            System.out.println("Phone number must contain exactly 10 digits.");
        }
    }
}
