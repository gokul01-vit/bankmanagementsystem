import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Represents one transaction made on a bank account. */
public class Transaction {
    private String type;
    private double amount;
    private String description;
    private LocalDateTime dateTime;

    public Transaction(String type, double amount, String description) {
        this.type = type;
        this.amount = amount;
        this.description = description;
        this.dateTime = LocalDateTime.now();
    }

    public void display() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        System.out.printf("%-18s %-12s Rs.%-10.2f %s%n",
                dateTime.format(formatter), type, amount, description);
    }
}
