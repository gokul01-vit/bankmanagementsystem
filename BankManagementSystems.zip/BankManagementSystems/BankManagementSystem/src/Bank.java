import java.util.ArrayList;

/** Manages all accounts in the bank. */
public class Bank {
    private ArrayList<Account> accounts;

    public Bank() {
        accounts = new ArrayList<>();
    }

    public boolean addAccount(Account account) {
        if (findAccount(account.getAccountNumber()) != null) return false;
        accounts.add(account);
        return true;
    }

    public Account findAccount(int accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber() == accountNumber) return account;
        }
        return null;
    }

    public ArrayList<Account> searchByName(String name) {
        ArrayList<Account> result = new ArrayList<>();
        for (Account account : accounts) {
            if (account.getCustomerName().toLowerCase().contains(name.toLowerCase())) {
                result.add(account);
            }
        }
        return result;
    }

    public boolean transfer(int from, int to, double amount) {
        Account sender = findAccount(from);
        Account receiver = findAccount(to);
        if (sender == null || receiver == null || from == to || amount <= 0) return false;
        if (!sender.transferOut(amount)) return false;
        receiver.transferIn(amount);
        return true;
    }

    public boolean closeAccount(int accountNumber) {
        Account account = findAccount(accountNumber);
        if (account == null || account.getBalance() != 0) return false;
        return accounts.remove(account);
    }

    public void displayAllAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts found.");
            return;
        }
        System.out.println("\n============================================================");
        System.out.printf("%-15s %-18s %-12s %s%n", "Account No.", "Name", "Type", "Balance");
        System.out.println("------------------------------------------------------------");
        for (Account account : accounts) account.displayRow();
        System.out.println("============================================================");
    }

    public int getAccountCount() { return accounts.size(); }
}
