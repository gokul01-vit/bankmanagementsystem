import java.util.ArrayList;

/** Represents a customer's bank account. */
public class Account {
    private int accountNumber;
    private String customerName;
    private String phoneNumber;
    private String accountType;
    private double balance;
    private ArrayList<Transaction> transactions;

    public Account(int accountNumber, String customerName, String phoneNumber,
                   String accountType, double initialDeposit) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.accountType = accountType;
        this.balance = initialDeposit;
        this.transactions = new ArrayList<>();
        if (initialDeposit > 0) {
            transactions.add(new Transaction("DEPOSIT", initialDeposit, "Initial deposit"));
        }
    }

    public int getAccountNumber() { return accountNumber; }
    public String getCustomerName() { return customerName; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAccountType() { return accountType; }
    public double getBalance() { return balance; }

    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public boolean deposit(double amount) {
        if (amount <= 0) return false;
        balance += amount;
        transactions.add(new Transaction("DEPOSIT", amount, "Cash deposit"));
        return true;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0 || amount > balance) return false;
        balance -= amount;
        transactions.add(new Transaction("WITHDRAW", amount, "Cash withdrawal"));
        return true;
    }

    public boolean transferOut(double amount) {
        if (!withdraw(amount)) return false;
        // Replace the withdrawal description with a transfer description through a new record.
        transactions.remove(transactions.size() - 1);
        transactions.add(new Transaction("TRANSFER OUT", amount, "Money transferred"));
        return true;
    }

    public void transferIn(double amount) {
        balance += amount;
        transactions.add(new Transaction("TRANSFER IN", amount, "Money received"));
    }

    public void displayDetails() {
        System.out.println("\n========================================");
        System.out.println("           ACCOUNT DETAILS");
        System.out.println("========================================");
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Customer Name  : " + customerName);
        System.out.println("Phone Number   : " + phoneNumber);
        System.out.println("Account Type   : " + accountType);
        System.out.printf("Balance        : Rs. %.2f%n", balance);
        System.out.println("========================================");
    }

    public void displayTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }
        System.out.println("\n===============================================================");
        System.out.println("                    TRANSACTION HISTORY");
        System.out.println("===============================================================");
        System.out.printf("%-18s %-12s %-15s %s%n", "Date & Time", "Type", "Amount", "Description");
        System.out.println("---------------------------------------------------------------");
        for (Transaction transaction : transactions) transaction.display();
        System.out.println("---------------------------------------------------------------");
        System.out.printf("Current Balance: Rs. %.2f%n", balance);
    }

    public void displayRow() {
        System.out.printf("%-15d %-18s %-12s Rs. %.2f%n",
                accountNumber, customerName, accountType, balance);
    }
}
